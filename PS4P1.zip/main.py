qty = input("Enter quantity of widgets")
taxamount = int(input("tax amount is"))

if qty > 10000:
  price = 10.00
elif qty < 10000 or qty > 5000:
  price = 20.00
elif qty < 5000:
  price = 30.00

extprice = (qty * price)
total = (extprice * 0.07)

print ("Quantity:   ", qty)
print ("Extended Price:   ", extprice)
print ("taxamount    ", taxamount)