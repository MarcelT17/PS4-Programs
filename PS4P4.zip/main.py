numberoftickets = int(input("Enter the number of concert tickets:"))

if numberoftickets >= 25.00:
  priceperticket = 50.00
elif numberoftickets >= 10.00 and numberoftickets <= 24.00:
  priceperticket = 60.00
elif numberoftickets >= 5.00 and numberoftickets <= 9.00:
  priceperticket = 70.00
else:
  priceperticket = 75.00

totalcost = int(numberoftickets * priceperticket)

print("Number of tickets:",numberoftickets)
print("Price per tickets:",priceperticket)
print("The total Cost:",totalcost)