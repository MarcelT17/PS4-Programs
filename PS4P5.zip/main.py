lastname = input("Enter your last name:")
salary = int(input("Enter Salary:"))
joblevel = int(input("Enter job level:"))

if joblevel >= 10.00:
  bonus = (salary * 25)/100
elif joblevel >= 5.00 and joblevel <= 9.00:
  bonus = (salary * 20)/100

print("hey, " + lastname," your bonus is:",bonus)