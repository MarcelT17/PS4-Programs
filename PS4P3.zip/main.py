principleamount = int(input("Enter principle amount of CD:"))
yeartomaturity = int(input("Enter to maturity:"))

if principleamount > 100000 and maturity == 5.00:
  interestrate == 7.00
elif principleamount >= 50000 and principleamount <= 100000 and yeartomaturity == 10.00:
  interestrate = 5.00
elif principleamount >= 50000 and principleamount <= 100000 and yeartomaturity == 5.00:
  interestrate = 4.00
else:
  interestrate = 2.00
  
interestrateforfirstyear = (principleamount * interestrate)/100

print("Principle      :",principleamount)
print("Interest Rate        :",interestrate)
print("Interest Rate amount for first year :",interestrateforfirstyear)